
<?php $__env->startSection('estilos'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/registros1.css')); ?>"> 

<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo','Atención de pacientes'); ?>


<?php $__env->startSection('menu'); ?>
    <button class="mobile-menu-btn" id="mobileMenuBtn">
        <i class="fas fa-bars"></i>
    </button>
    
    <nav class="main-nav" id="mainNav">
        <!-- Pacientes -->
        <div class="nav-item">
            <a  class="nav-link" id="pacientesLink">
                <i class="fas fa-user-injured nav-icon"></i>
                <span>Pacientes</span>
            </a>
            <div class="submenu">
                <a href="http://localhost/laravel/estadia/public/atencion_paciente" class="submenu-link">
                    <i class="fa-regular fa-pen-to-square"></i> Atender Paciente
                </a>
                <a href="http://localhost/laravel/estadia/public/lista_pacientes" class="submenu-link">
                    <i class="fas fa-list"></i> Lista de Pacientes
                </a>
                <a href="http://localhost/laravel/estadia/public/lista_atenciones" class="submenu-link">
                    <i class="fas fa-chart-bar"></i> Lista de Atenciones
                </a>
        
            </div>
        </div>
        <!-- Incidencias -->
        <div class="nav-item">
            <a  class="nav-link" id="pacientesLink">
                <i class="fa-solid fa-file-invoice"></i>
                <span>Incidencias</span>
            </a>
            <div class="submenu">
                <a href="http://localhost/laravel/estadia/public/registro_incidencias" class="submenu-link">
                    <i class="fas fa-exclamation-triangle"></i> Reportar Incidencia
                </a>
                <a href="http://localhost/laravel/estadia/public/historial_incidencias" class="submenu-link">
                    <i class="fas fa-history"></i> Historial de Incidencias
                </a>
                <a href="http://localhost/laravel/estadia/public/tabla_areas" class="submenu-link">
                    <i class="fa-solid fa-expand"></i> Áreas
                </a>
                <a href="http://localhost/laravel/estadia/public/tabla_materiales" class="submenu-link">
                    <i class="fa-solid fa-toolbox"></i> Materiales o Equipos
                </a>
                <a href="http://localhost/laravel/estadia/public/tabla_incidentes" class="submenu-link">
                    <i class="fa-solid fa-person-falling-burst"></i> Tipo de Incidente
                </a>
                <a href="http://localhost/laravel/estadia/public/tabla_riesgos" class="submenu-link">
                    <i class="fa-solid fa-explosion"></i> Tipo de Riesgo
                </a>
                 <a href="http://localhost/laravel/estadia/public/tabla_niveles" class="submenu-link">
                    <i class="fa-solid fa-skull-crossbones"></i> Nivel de Riesgo
                </a>
            </div>
        </div>
        
        <!-- Fumigaciones -->
        <div class="nav-item">
            <a  class="nav-link" id="fumigacionesLink">
                <i class="fas fa-spray-can nav-icon"></i>
                <span>Fumigaciones</span>
            </a>
            <div class="submenu">
                <a href="http://localhost/laravel/estadia/public/tabla_fumigaciones" class="submenu-link">
                    <i class="fa-solid fa-table"></i> Tabla de Fumigaciones 
                </a>
                <a href="/fumigaciones/historial" class="submenu-link">
                    <i class="fas fa-clipboard-list"></i> Historial
                </a>
                <a href="http://localhost/laravel/estadia/public/lista_responsables" class="submenu-link">
                    <i class="fa-solid fa-person"></i> Reponsables
                </a>
                <a href="http://localhost/laravel/estadia/public/tabla_equipos" class="submenu-link">
                    <i class="fa-solid fa-toolbox"></i> Equipos de Fumigación
                </a>
                <a href="http://localhost/laravel/estadia/public/tabla_areas" class="submenu-link">
                    <i class="fa-solid fa-cube"></i> Áreas
                </a>
            </div>
        </div>
        
        <!-- Extintores -->
        <div class="nav-item">
            <a  class="nav-link" id="extintoresLink">
                <i class="fas fa-fire-extinguisher nav-icon"></i>
                <span>Extintores</span>
            </a>
            <div class="submenu">
                <a href="http://localhost/laravel/estadia/public/registro_extintores" class="submenu-link">
                    <i class="fa-solid fa-circle-plus"></i> Nuevo Extintor
                </a>
                <a href="http://localhost/laravel/estadia/public/inventario_extintores" class="submenu-link">
                    <i class="fas fa-boxes"></i> Inventario
                </a>
                <a href="http://localhost/laravel/estadia/public/tabla_mantenimientos" class="submenu-link">
                    <i class="fas fa-tools"></i> Mantenimiento
                </a>
                <a href="http://localhost/laravel/estadia/public/tabla_areas" class="submenu-link">
                    <i class="fas fa-clipboard-check"></i> Áreas
                </a>
            </div>
        </div>
        <div class="nav-item">
            <div name="trigger">
                <a  class="btn btn-register" id="extintoresLink">
                    <i class="fa-solid fa-id-card"></i>
                    <span>Sesion de <?php echo e(Auth::user()->name); ?></span>
                </a>
            </div>
            
            <div class="submenu" name="content">
                <a href="http://localhost/laravel/estadia/public/dashboard" class="submenu-link">
                    <i class="fa-regular fa-window-maximize"></i> Inicio
                </a>
                <a :href="route('profile.edit')" class="submenu-link">
                    <i class="fa-solid fa-id-card-clip"></i> <?php echo e(__('Profile')); ?>

                </a>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <a :href="route('logout')"
                    onclick="event.preventDefault();
                                this.closest('form').submit();"
                                class="submenu-link">
                                <i class="fa-solid fa-door-open"></i> <?php echo e(__('Log Out')); ?>

                    </a>
                </form>
            </div>
        </div>
    </nav>


<?php $__env->stopSection(); ?>
 <!-- contenido ----------------------------------------------------------------------------------------------------------------------------------->
 <?php $__env->startSection('contenido'); ?>
 <!-- Hero Section -->
 <section class="hero">
    <div class="login-wrapper">
        <div class="logo-text">
            <h1>Atención a Pacientes</h1>
        </div>
        <div class="row ">
            <div class="col-md-6 justify-content-center" >
                <?php if(session('status')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('status')); ?>

                        <button type="button" class="btn-login" date-bs-dismiss="alert" ariel-label="Cerrar"></button>
                    
                <?php endif; ?>
            </div>
        </div>

        <form method="POST" action="<?php echo e($atencion->exists ? route('atencions.update', $atencion) : route('atencions.store')); ?>" class="login-form">
            <?php echo csrf_field(); ?>
            <?php if($atencion->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
             <!-- Name/Nombre -->
            <div class="form-group">
                <label >
                    <i class="fa-solid fa-person"></i> Paciente
                    <a href="<?php echo e(route('pacientes.create')); ?>" type="button" class="btn btn-outline-secondary"><i class="fa-solid fa-circle-up"></i>Paciente Nuevo</a>
                </label>
                
                    <input type="text" id="paciente_input" list="pacientes_list" class="form-control form-control-lg" 
                           placeholder="Ingrese el Nombre Completo..." >
                           
                            <input type="hidden" name="paciente_id" id="paciente_id">
                           
                           <datalist id="pacientes_list" >
                            <?php $__currentLoopData = $pacientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paciente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option 
                            data-id="<?php echo e($paciente->id); ?>"
                            value="<?php echo e($paciente->nombre); ?> - <?php echo e($paciente->codigo); ?> - <?php echo e($paciente->edad); ?> - <?php echo e($paciente->carrera_area); ?> - <?php echo e($paciente->semestre); ?>">
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </datalist>
                           <?php $__errorArgs = ['paciente_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>     
                        <div class="logo-text">
                            <p><?php echo e($message); ?></p> 
                        </div>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           
                        
            </div>
            <!-- Email Address/Correo Electronico -->
            <div class="form-group">
                <label>
                    <i class="fa-regular fa-calendar-days"></i> Hora de Atención 

                </label>
                <input type="text" id="hora_atencion" name="hora_atencion" value="<?php echo e(old('hora_atencion', $atencion->hora_atencion)); ?>"
                       placeholder="Hora de Atención... " required autofocus autocomplete="hora_atencion">
                       <?php $__errorArgs = ['hora_atencion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>     
                    <div class="logo-text">
                        <p><?php echo e($message); ?></p> 
                    </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      
            </div>
            <div class="logo-text">
                <p><i class="fa-solid fa-file-waveform"></i> Signos Vitales</p>
            </div>
             
            <div class="form-group">
                <label >
                    <i class="fa-solid fa-heart-pulse"></i> Frecuencia Cardíaca
                </label>
                <input type="text" id="frecuencia_cardiaca" name="frecuencia_cardiaca" value="<?php echo e(old('frecuencia_cardiaca', $atencion->frecuencia_cardiaca)); ?>"
                       placeholder="Descripción..." required autofocus autocomplete="frecuencia_cardiaca">
                       <?php $__errorArgs = ['frecuencia_cardiaca'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>     
                    <div class="logo-text">
                        <p><?php echo e($message); ?></p> 
                    </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      
            </div>
            <div class="form-group">
                <label >
                    <i class="fa-solid fa-lungs"></i> Frecuencia Respiratoria
                </label>
                <input type="text" id="frecuencia_respiratoria" name="frecuencia_respiratoria" value="<?php echo e(old('frecuencia_respiratoria', $atencion->frecuencia_respiratoria)); ?>"
                       placeholder="Descripción..." required autofocus autocomplete="frecuencia_respiratoria">
                       <?php $__errorArgs = ['frecuencia_respiratoria'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>     
                    <div class="logo-text">
                        <p><?php echo e($message); ?></p> 
                    </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      
            </div>
            <div class="form-group">
                <label >
                    <i class="fa-solid fa-up-long"></i> Tensión Sistólica
                </label>
                <input type="text" id="tension_sistolica" name="tension_sistolica" value="<?php echo e(old('tension_sistolica', $atencion->tension_sistolica)); ?>"
                       placeholder="Descripción..." required autofocus autocomplete="tension_sistolica">
                       <?php $__errorArgs = ['tension_sistolica'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>     
                    <div class="logo-text">
                        <p><?php echo e($message); ?></p> 
                    </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      
            </div>
            <div class="form-group">
                <label >
                    <i class="fa-solid fa-down-long"></i> Tensión Diastólica
                </label>
                <input type="text" id="tension_diastolica" name="tension_diastolica" value="<?php echo e(old('tension_diastolica', $atencion->tension_diastolica)); ?>"
                       placeholder="Descripción..." required autofocus autocomplete="tension_diastolica">
                       <?php $__errorArgs = ['tension_diastolica'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>     
                    <div class="logo-text">
                        <p><?php echo e($message); ?></p> 
                    </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      
            </div>
            <div class="form-group">
                <label >
                    <i class="fa-solid fa-temperature-low"></i> Temperatura
                </label>
                <input type="text" id="temperatura" name="temperatura" value="<?php echo e(old('temperatura', $atencion->temperatura)); ?>"
                       placeholder="Descripción..." required autofocus autocomplete="temperatura">
                       <?php $__errorArgs = ['temperatura'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>     
                    <div class="logo-text">
                        <p><?php echo e($message); ?></p> 
                    </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      
            </div>
            <div class="form-group">
                <label >
                    <i class="fa-solid fa-arrow-up-wide-short"></i> Oxigenación
                </label>
                <input type="text" id="oxigenacion" name="oxigenacion" value="<?php echo e(old('oxigenacion', $atencion->oxigenacion)); ?>"
                       placeholder="Descripción..." required autofocus autocomplete="oxigenacion">
                       <?php $__errorArgs = ['oxigenacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>     
                    <div class="logo-text">
                        <p><?php echo e($message); ?></p> 
                    </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      
            </div>
            <div class="form-group">
                <label >
                    <i class="fa-notdog fa-solid fa-droplet" style="color: #cc0000;"></i> Glucemia
                </label>
                <input type="text" id="glucemia" name="glucemia" value="<?php echo e(old('glucemia', $atencion->glucemia)); ?>"
                       placeholder="Descripción..." required autofocus autocomplete="glucemia">
                       <?php $__errorArgs = ['glucemia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>     
                    <div class="logo-text">
                        <p><?php echo e($message); ?></p> 
                    </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      
            </div>
            <div class="logo-text">
               <p><i class="fa-solid fa-clipboard-user"></i> Valoración SAMPLE</p>
            </div>
             
            <div class="form-group">
                <label >
                    <i class="fa-solid fa-file-signature"></i> Signos y Síntomas 
                </label>
                <input type="text" id="signos_sintomas" name="signos_sintomas" value="<?php echo e(old('signos_sintomas', $atencion->signos_sintomas)); ?>"
                       placeholder="Descripción..." required autofocus autocomplete="signos_sintomas">
                       <?php $__errorArgs = ['signos_sintomas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>     
                    <div class="logo-text">
                        <p><?php echo e($message); ?></p> 
                    </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      
            </div>

            <div class="form-group">
                <label >
                    <i class="fa-solid fa-head-side-cough"></i> Alergias
                </label>
                <input type="text" id="alergias" name="alergias" value="<?php echo e(old('alergias', $atencion->alergias)); ?>"
                       placeholder="Descripción..." required autofocus autocomplete="alergias">
                       <?php $__errorArgs = ['alergias'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>     
                    <div class="logo-text">
                        <p><?php echo e($message); ?></p> 
                    </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      
            </div>

            <div class="form-group">
                <label >
                    <i class="fa-solid fa-capsules"></i> Medicamentos
                </label>
                <input type="text" id="medicamento" name="medicamento" value="<?php echo e(old('medicamento', $atencion->medicamento)); ?>"
                       placeholder="Descripción..." required autofocus autocomplete="medicamento">
                       <?php $__errorArgs = ['medicamento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>     
                    <div class="logo-text">
                        <p><?php echo e($message); ?></p> 
                    </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      
            </div>
            <div class="form-group">
                <label >
                    <i class="fa-solid fa-utensils"></i> Patologia
                </label>
                <input type="text" id="patologia" name="patologia" value="<?php echo e(old('patologia', $atencion->patologia)); ?>"
                       placeholder="Descripción..." required autofocus autocomplete="patologia">
                       <?php $__errorArgs = ['patologia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>     
                    <div class="logo-text">
                        <p><?php echo e($message); ?></p> 
                    </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      
            </div>

            <div class="form-group">
                <label >
                    <i class="fa-solid fa-utensils"></i> Último Alimento
                </label>
                <input type="text" id="ultimo_alimento" name="ultimo_alimento" value="<?php echo e(old('ultimo_alimento', $atencion->ultimo_alimento)); ?>"
                       placeholder="Descripción..." required autofocus autocomplete="ultimo_alimento">
                       <?php $__errorArgs = ['ultimo_alimento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>     
                    <div class="logo-text">
                        <p><?php echo e($message); ?></p> 
                    </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      
            </div>

            <div class="form-group">
                <label >
                    <i class="fa-solid fa-calendar-day"></i> Eventos Previos
                </label>
                <input type="text" id="eventos_previos" name="eventos_previos" value="<?php echo e(old('eventos_previos', $atencion->eventos_previos)); ?>"
                       placeholder="Descripción..." required autofocus autocomplete="eventos_previos">
                       <?php $__errorArgs = ['eventos_previos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>     
                    <div class="logo-text">
                        <p><?php echo e($message); ?></p> 
                    </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      
            </div>

            <div class="form-group">
                <label>
                    <i class="fa-solid fa-location-dot"></i> Destino
                </label>
                <input type="text" id="destino" name="destino" value="<?php echo e(old('destino', $atencion->destino)); ?>"
                       placeholder="Escriba el destino" required autofocus autocomplete="destino">
                       <?php $__errorArgs = ['destino'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>     
                    <div class="logo-text">
                        <p><?php echo e($message); ?></p> 
                    </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      
            </div>
        
            <div class="flex items-center justify-end mt-4">
                <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['class' => 'btn btn-login']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'btn btn-login']); ?>
                    <i class="fa-solid fa-check-to-slot"></i> <?php echo e($atencion->exists ? 'Actualizar' : 'Registrar'); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
                
            </div>
        </form>
        
        <div id="message" class="message"></div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Menú móvil
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const mainNav = document.getElementById('mainNav');
        
        mobileMenuBtn.addEventListener('click', function() {
            mainNav.classList.toggle('active');
            mobileMenuBtn.innerHTML = mainNav.classList.contains('active') 
                ? '<i class="fas fa-times"></i>' 
                : '<i class="fas fa-bars"></i>';
        });
        
        // Cerrar menú al hacer clic en un enlace
        const navLinks = document.querySelectorAll('.nav-link, .submenu-link');
        navLinks.forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 900) {
                    mainNav.classList.remove('active');
                    mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>';
                }
            });
        });
        document.getElementById('paciente_input').addEventListener('input', function () {

let input = this.value;
let options = document.querySelectorAll('#pacientes_list option');
let hidden = document.getElementById('paciente_id');

hidden.value = '';

options.forEach(option => {

    if(option.value === input){
        hidden.value = option.dataset.id;
    }

});

});
    });
</script>
    
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layouts.template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\estadia\resources\views/atencions/form.blade.php ENDPATH**/ ?>