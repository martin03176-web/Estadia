
<?php $__env->startSection('estilos'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/registros1.css')); ?>">    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titulo','Registro de pacientes'); ?>
 <!-- botones ------------------------------------------------------------------------------------------------------------------------------->

<?php $__env->startSection('menu'); ?>
 <button class="mobile-menu-btn" id="mobileMenuBtn">
     <i class="fas fa-bars"></i>
 </button>
 
 <nav class="main-nav" id="mainNav">
     <!-- Pacientes -->
     <div class="nav-item">
         <a  class="nav-link" id="pacientesLink">
             <i class="fas fa-user-injured nav-icon"></i>
             <span>Pacientes</span>
         </a>
         <div class="submenu">
             <a href="http://localhost/laravel/estadia/public/atencion_paciente" class="submenu-link">
                 <i class="fa-regular fa-pen-to-square"></i> Atender Paciente
             </a>
             <a href="http://localhost/laravel/estadia/public/lista_pacientes" class="submenu-link">
                 <i class="fas fa-list"></i> Lista de Pacientes
             </a>
             <a href="http://localhost/laravel/estadia/public/lista_atenciones" class="submenu-link">
                 <i class="fas fa-chart-bar"></i> Lista de Atenciones
             </a>
     
         </div>
     </div>
     <!-- Incidencias -->
     <div class="nav-item">
         <a  class="nav-link" id="pacientesLink">
             <i class="fa-solid fa-file-invoice"></i>
             <span>Incidencias</span>
         </a>
         <div class="submenu">
             <a href="http://localhost/laravel/estadia/public/registro_incidencias" class="submenu-link">
                 <i class="fas fa-exclamation-triangle"></i> Reportar Incidencia
             </a>
             <a href="http://localhost/laravel/estadia/public/historial_incidencias" class="submenu-link">
                 <i class="fas fa-history"></i> Historial de Incidencias
             </a>
             <a href="http://localhost/laravel/estadia/public/tabla_areas" class="submenu-link">
                 <i class="fa-solid fa-expand"></i> Áreas
             </a>
             <a href="http://localhost/laravel/estadia/public/tabla_materiales" class="submenu-link">
                 <i class="fa-solid fa-toolbox"></i> Materiales o Equipos
             </a>
             <a href="http://localhost/laravel/estadia/public/tabla_incidentes" class="submenu-link">
                 <i class="fa-solid fa-person-falling-burst"></i> Tipo de Incidente
             </a>
             <a href="http://localhost/laravel/estadia/public/tabla_riesgos" class="submenu-link">
                 <i class="fa-solid fa-explosion"></i> Tipo de Riesgo
             </a>
              <a href="http://localhost/laravel/estadia/public/tabla_niveles" class="submenu-link">
                 <i class="fa-solid fa-skull-crossbones"></i> Nivel de Riesgo
             </a>
         </div>
     </div>
     
     <!-- Fumigaciones -->
     <div class="nav-item">
         <a  class="nav-link" id="fumigacionesLink">
             <i class="fas fa-spray-can nav-icon"></i>
             <span>Fumigaciones</span>
         </a>
         <div class="submenu">
             <a href="http://localhost/laravel/estadia/public/tabla_fumigaciones" class="submenu-link">
                 <i class="fa-solid fa-table"></i> Tabla de Fumigaciones 
             </a>
             <a href="/fumigaciones/historial" class="submenu-link">
                 <i class="fas fa-clipboard-list"></i> Historial
             </a>
             <a href="http://localhost/laravel/estadia/public/lista_responsables" class="submenu-link">
                 <i class="fa-solid fa-person"></i> Reponsables
             </a>
             <a href="http://localhost/laravel/estadia/public/tabla_equipos" class="submenu-link">
                 <i class="fa-solid fa-toolbox"></i> Equipos de Fumigación
             </a>
             <a href="http://localhost/laravel/estadia/public/tabla_areas" class="submenu-link">
                 <i class="fa-solid fa-cube"></i> Áreas
             </a>
         </div>
     </div>
     
     <!-- Extintores -->
     <div class="nav-item">
         <a  class="nav-link" id="extintoresLink">
             <i class="fas fa-fire-extinguisher nav-icon"></i>
             <span>Extintores</span>
         </a>
         <div class="submenu">
             <a href="http://localhost/laravel/estadia/public/registro_extintores" class="submenu-link">
                 <i class="fa-solid fa-circle-plus"></i> Nuevo Extintor
             </a>
             <a href="http://localhost/laravel/estadia/public/inventario_extintores" class="submenu-link">
                 <i class="fas fa-boxes"></i> Inventario
             </a>
             <a href="http://localhost/laravel/estadia/public/tabla_mantenimientos" class="submenu-link">
                 <i class="fas fa-tools"></i> Mantenimiento
             </a>
             <a href="http://localhost/laravel/estadia/public/tabla_areas" class="submenu-link">
                 <i class="fas fa-clipboard-check"></i> Áreas
             </a>
         </div>
     </div>
     <div class="nav-item">
         <div name="trigger">
             <a  class="btn btn-register" id="extintoresLink">
                 <i class="fa-solid fa-id-card"></i>
                 <span>Sesion de <?php echo e(Auth::user()->name); ?></span>
             </a>
         </div>
         
         <div class="submenu" name="content">
             <a href="http://localhost/laravel/estadia/public/dashboard" class="submenu-link">
                 <i class="fa-regular fa-window-maximize"></i> Inicio
             </a>
             <a :href="route('profile.edit')" class="submenu-link">
                 <i class="fa-solid fa-id-card-clip"></i> <?php echo e(__('Profile')); ?>

             </a>
             <form method="POST" action="<?php echo e(route('logout')); ?>">
                 <?php echo csrf_field(); ?>
                 <a :href="route('logout')"
                 onclick="event.preventDefault();
                             this.closest('form').submit();"
                             class="submenu-link">
                             <i class="fa-solid fa-door-open"></i> <?php echo e(__('Log Out')); ?>

                 </a>
             </form>
         </div>
     </div>
 </nav>


<?php $__env->stopSection(); ?>
 <!-- contenido ----------------------------------------------------------------------------------------------------------------------------------->
<?php $__env->startSection('contenido'); ?>
 <!-- Hero Section -->
 <section class="hero">
    <div class="login-wrapper">
        <div class="logo-text">
            <h1>Registro de Paciente</h1>
        </div>
        <div class="row ">
            <div class="col-md-6 justify-content-center" >
                <?php if(session('status')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('status')); ?>

                        <button type="button" class="btn-login" date-bs-dismiss="alert" ariel-label="Cerrar"></button>
                    
                <?php endif; ?>
            </div>
        </div>

        <form method="POST" action="<?php echo e($paciente->exists ? route('pacientes.update', $paciente) : route('pacientes.store')); ?>" class="login-form">
            <?php echo csrf_field(); ?>
            <?php if($paciente->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
             <!-- Name/Nombre -->
            <div class="form-group">
                <label >
                    <i class="fas fa-user"></i> Nombre Completo
                </label>
                <input type="text" id="nombre" name="nombre" value="<?php echo e(old('nombre', $paciente->nombre)); ?>"
                       placeholder="Ingrese Nombre del Paciente" required autofocus autocomplete="nombre">
                       <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>     
                    <div class="logo-text">
                        <p><?php echo e($message); ?></p> 
                    </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      
            </div>
            <!-- Email Address/Correo Electronico -->
            <div class="form-group">
                <label >
                    <i class="fa-regular fa-calendar-days"></i> Edad
                </label>
                <input type="number" id="edad" name="edad" value="<?php echo e(old('edad', $paciente->edad)); ?>"
                       placeholder="Ingrese Edad del Paciente" required autofocus autocomplete="edad">
                       <?php $__errorArgs = ['edad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>     
                    <div class="logo-text">
                        <p><?php echo e($message); ?></p> 
                    </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      
            </div>
            <div class="form-group">
                <label >
                    <i class="fas fa-user"></i> Sexo
                </label>
                <select class="form-select form-select-lg mb-3" aria-label="Large select example" name="sexo" >
                    <option value="Masculino" <?php if(old('sexo', $paciente->sexo) === 'Masculino' ): echo 'selected'; endif; ?>>Masculino</option>
                    <option value="Femenino" <?php if(old('sexo', $paciente->sexo) === 'Femenino' ): echo 'selected'; endif; ?>>Femenino</option>
                    <option value="Otro" <?php if(old('sexo', $paciente->sexo) === 'Otro' ): echo 'selected'; endif; ?>>Otro</option>
                  </select>
                  <?php $__errorArgs = ['sexo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>     
                  <div class="logo-text">
                      <p><?php echo e($message); ?></p> 
                  </div>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    
            </div>

           
            <div class="form-group">
                <label >
                    <i class="fa-solid fa-square-phone"></i> Teléfono
                </label>
                <input type="number" id="telefono" name="telefono" value="<?php echo e(old('telefono', $paciente->telefono)); ?>"
                       placeholder="Ingrese Número Telefónico" required autofocus autocomplete="telefono">
                       <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>     
                    <div class="logo-text">
                        <p><?php echo e($message); ?></p> 
                    </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      
            </div>
            
            <div class="form-group">
                <label >
                    <i class="fa-solid fa-qrcode"></i> Código
                </label>
                <input type="number" id="codio" name="codigo" value="<?php echo e(old('codigo', $paciente->codigo)); ?>"
                       placeholder="Ingrese Código del Paciente" required autofocus autocomplete="codigo">
                       <?php $__errorArgs = ['codigo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>     
                    <div class="logo-text">
                        <p><?php echo e($message); ?></p> 
                    </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      
            </div>

            <div class="form-group">
                <label >
                    <i class="fa-solid fa-book-bookmark"></i> Carrera o Área
                </label>
                <input type="text" id="carrera_area" name="carrera_area" value="<?php echo e(old('carrera_area', $paciente->carrera_area)); ?>"
                       placeholder="Ingrese Carrera del Paciente" required autofocus autocomplete="carrera_area">
                       <?php $__errorArgs = ['carrera_area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>     
                    <div class="logo-text">
                        <p><?php echo e($message); ?></p> 
                    </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      
            </div>

            <div class="form-group">
                <label >
                    <i class="fa-solid fa-business-time"></i> Semestre
                </label>
                <input type="text" id="semestre" name="semestre" value="<?php echo e(old('semestre', $paciente->semestre)); ?>"
                       placeholder="Ingrese el Semestre" required autofocus autocomplete="semestre">
                       <?php $__errorArgs = ['semestre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>     
                    <div class="logo-text">
                        <p><?php echo e($message); ?></p> 
                    </div>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      
            </div>
        
            <div class="flex items-center justify-end mt-4">
                <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['class' => 'btn btn-login']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'btn btn-login']); ?>
                    <i class="fa-solid fa-check-to-slot"></i> <?php echo e($paciente->exists ? 'Actualizar' : 'Registrar'); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
            </div>
        </form>
        
        <div id="message" class="message"></div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Menú móvil
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const mainNav = document.getElementById('mainNav');
        
        mobileMenuBtn.addEventListener('click', function() {
            mainNav.classList.toggle('active');
            mobileMenuBtn.innerHTML = mainNav.classList.contains('active') 
                ? '<i class="fas fa-times"></i>' 
                : '<i class="fas fa-bars"></i>';
        });
        
        // Cerrar menú al hacer clic en un enlace
        const navLinks = document.querySelectorAll('.nav-link, .submenu-link');
        navLinks.forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 900) {
                    mainNav.classList.remove('active');
                    mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>';
                }
            });
        });
    });
</script>
    
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layouts.template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\estadia\resources\views/pacientes/form.blade.php ENDPATH**/ ?>