<footer class="footer">
    <p>© <?php echo date('Y'); ?> Universidad de Guadalajara - CUCSH</p>
</footer>

</body>
</html>