<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class nivel_riesgo extends Model
{
    //
}
