<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class equipo_fumigacion extends Model
{
    //
}
