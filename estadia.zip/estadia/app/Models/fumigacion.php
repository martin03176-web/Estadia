<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class fumigacion extends Model
{
    //
}
