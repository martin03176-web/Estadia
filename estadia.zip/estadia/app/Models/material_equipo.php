<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class material_equipo extends Model
{
    //
}
